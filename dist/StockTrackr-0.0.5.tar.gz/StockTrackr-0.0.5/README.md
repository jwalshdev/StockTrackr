# StockTrackr

This is a basic application that uses alpha_vantages API to pull stock data as well as monitor it real-time.